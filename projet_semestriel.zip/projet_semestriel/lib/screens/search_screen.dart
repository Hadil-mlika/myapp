import 'package:betakati_app/widgets/my_button.dart';
import 'package:flutter/material.dart';

class SearchScreen extends StatefulWidget {
  static const String screenRoute = 'signin_screen';

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Search 🔍'),
        backgroundColor: Colors.deepOrangeAccent[400],
      ),
      backgroundColor: Colors.orange[100],
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 22),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 200,
              child: Column(
                children: [
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.orange[800],
                    title: ' Doctor  👨‍⚕️',
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.redAccent[700],
                    title: '  Blood Groups 💉 ',
                    onPressed: () {},
                  )
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
