import 'package:betakati_app/widgets/my_button.dart';
import 'package:flutter/material.dart';

class BloodGroupsScreen extends StatefulWidget {
  static const String screenRoute = 'bloodGroupsScreen_screen';

  @override
  _BloodGroupsScreenState createState() => _BloodGroupsScreenState();
}

class _BloodGroupsScreenState extends State<BloodGroupsScreen> {
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Blood Types  💉 '),
        backgroundColor: Colors.deepOrangeAccent[400],
      ),
      backgroundColor: Colors.orange[100],
      body: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              height: 652.9,
              child: Column(
                children: [
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.amber[700],
                    title: ' O+ ',
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.orange[800],
                    title: ' O- ',
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.deepOrangeAccent[100],
                    title: ' A+ ',
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 2,
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.orange[800],
                    title: ' A- ',
                    onPressed: () {},
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.redAccent[700],
                    title: ' B+ ',
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.orange[300],
                    title: ' B- ',
                    onPressed: () {},
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.deepOrange,
                    title: ' AB+ ',
                    onPressed: () {},
                  ),
                  SizedBox(
                    height: 1,
                  ),
                  MyButton(
                    Icon(
                      Icons.account_circle,
                      color: Colors.white,
                    ),
                    color: Colors.deepOrange[400],
                    title: ' AB- ',
                    onPressed: () {},
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
